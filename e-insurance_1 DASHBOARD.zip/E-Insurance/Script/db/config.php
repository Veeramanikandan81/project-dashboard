<?php
DEFINE('DBHost','127.0.0.1');
DEFINE('DBUser', 'root');
DEFINE('DBPass','');
DEFINE('DBName','E-Insurance');
DEFINE('DBCharset','utf8mb4');
DEFINE('DBCollation', 'utf8_general_ci');
DEFINE('DBPrefix', '');
?>
