<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Request a Quote</title>

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">

    <style>
        @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@500&display=swap');

        * {
            margin: 0;
            padding: 0;
            font-family: 'Poppins', sans-serif;
            box-sizing: border-box;
        }

        body {
            background-image: linear-gradient(to top, #accbee 0%, #fff 75%, #fff 100%);
            background-size: cover;
            background-attachment: fixed;
            background-repeat: no-repeat;
        }

        .main {
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }
        
        .quote-container {
            padding: 30px;
            border-radius: 10px;
            width: 70%;
            background-color: rgba(255, 255, 255, 0.8);
            box-shadow: rgba(0, 0, 0, 0.35) 0px 5px 15px;
        }
    </style>
</head>
<body>
    
        <div class="main">
            <h1>Request a Quote</h1>
            <p class="mb-4">Welcome to our request a quote page, where we're eager to provide you with tailored pricing solutions for your needs.</p>
            <div class="quote-container">
                <form action="./send-quote.php" method="POST">
                    <div class="form-row">
                        <div class="form-group col-6">
                            <label for="firstName">First Name:</label>
                            <input type="text" class="form-control"  id="firstName" name="first_name" required>
                        </div>
                        <div class="form-group col-6">
                            <label for="lastName">Last Name:</label>
                            <input type="text" class="form-control" id="lastName" name="last_name" required>
                        </div>
                    </div>
                    <div class="form-row">
                        <div class="form-group col-6">
                            <label for="phoneNum">Phone Number:</label>
                            <input type="number" class="form-control" id="phoneNum" name="phone_number" required>
                        </div>
                        <div class="form-group col-6">
                            <label for="emailAdd">Email Address:</label>
                            <input type="email" class="form-control" id="emailAdd" name="email_address" required>
                        </div>
                    </div>
                    <div class="form-row">
                        <div class="form-group col-6">
                            <label for="qouteFor">What would you like a quote for?</label>
                            <input type="text" class="form-control" id="quoteFor" name="quote_for" required>
                        </div>
                        <div class="form-group col-6">
                            <label for="budget">Your Budget:</label>
                            <input type="number" class="form-control" id="budget" name="budget" required>
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="furtherInfo">Please provide us further info for your quote.</label>
                        <textarea class="form-control" id="furtherInfo" name="further_info" cols="30" rows="6" required></textarea>
                    </div>
                    <button type="submit" class="btn btn-primary float-right">Send Quote ></button>
                </form>

            </div>

        </div>

</body>
</html>