<?php

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

// Required files
require 'phpmailer/src/Exception.php';
require 'phpmailer/src/PHPMailer.php';
require 'phpmailer/src/SMTP.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') { 
    $mail = new PHPMailer(true);
    
    $firstName = $_POST['first_name'];
    $lastName = $_POST['last_name'];
    $fullName = $firstName . ' '. $lastName;
    $phoneNumber = $_POST['phone_number'];
    $emailAdd = $_POST['email_address'];
    $quoteFor = $_POST['quote_for'];
    $budget = $_POST['budget'];
    $furtherInfo = $_POST['further_info'];

    try {
        // Server settings
        $mail->isSMTP();
        $mail->Host       = 'smtp.gmail.com';
        $mail->SMTPAuth   = true;
        $mail->Username   = 'kimjisooishart@gmail.com';
        $mail->Password   = 'yrzibmtdsxcjqsgw';
        $mail->SMTPSecure = 'ssl';
        $mail->Port       = 465;

        // Recipients
        $mail->setFrom($emailAdd, $fullName);
        $mail->addAddress($emailAdd);
        $mail->addReplyTo($emailAdd, $fullName);

        // Content
        $mail->isHTML(true);
        $mail->Subject = 'Quote Request';
        $mail->Body    = "
            <p>Name: $fullName</p>
            <p>Phone Number: $phoneNumber</p>
            <p>Email Address: $emailAdd</p>
            <p>Quote For: $quoteFor</p>
            <p>Budget: $budget</p>
            <p>Further Information: $furtherInfo</p>
        ";

        $mail->send();
        echo "
            <script>
            alert('Quote was sent successfully. Thank you for reaching out to us!');
            window.location.href = 'index.php';
            </script>
        ";
    } catch (Exception $e) {
        echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
    }
}
?>
